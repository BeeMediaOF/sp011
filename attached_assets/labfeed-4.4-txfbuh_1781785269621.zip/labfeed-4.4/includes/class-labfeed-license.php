<?php
if (!defined('ABSPATH')) exit;

class LabFeed_License {
    private static $api_url = 'https://pluginpress.com.br/wp-json/labfeed/v1/validate';

    public static function is_active() {
        $token = trim(get_option('labfeed_license_token', ''));
        if (!$token) return false;

        $cache_key = 'labfeed_license_' . md5($token);
        $cached = get_transient($cache_key);

        if (is_array($cached)) {
            // Se o status for 'active' e não expirou fisicamente no WP (transient), confiamos.
            // Se o status NÃO for 'active', revalidamos para ver se mudou.
            if (($cached['status'] ?? '') === 'active') {
                return true;
            }
        }

        return self::validate_remotely($token);
    }

    public static function validate_remotely($token) {
        $domain = parse_url(home_url(), PHP_URL_HOST) ?: ($_SERVER['HTTP_HOST'] ?? '');
        $domain = strtolower(preg_replace('/^www\./i', '', trim($domain)));

        $response = wp_remote_post(self::$api_url, [
            'timeout' => 10,
            'sslverify' => false,
            'headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json'],
            'body' => wp_json_encode(['token' => $token, 'domain' => $domain])
        ]);

        if (is_wp_error($response)) {
            // Se houver erro de conexão, tentamos usar o cache antigo por mais um tempo se ele existir
            $cache_key = 'labfeed_license_' . md5($token);
            $cached = get_transient($cache_key);
            return (isset($cached['status']) && $cached['status'] === 'active');
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($data) || !isset($data['status'])) return false;

        $cache_key = 'labfeed_license_' . md5($token);
        $status = $data['status'];
        
        // Aumentado para 12 horas se sucesso, 10 min se erro
        $ttl = ($status === 'success') ? 12 * HOUR_IN_SECONDS : 10 * MINUTE_IN_SECONDS;

        set_transient($cache_key, [
            'status' => ($status === 'success' ? 'active' : $status),
            'expires_at' => $data['expires_at'] ?? null,
            'notice' => $data['notice'] ?? ''
        ], $ttl);

        return $status === 'success';
    }

    public static function render_activation_notice() {
        // Mostrar apenas nas páginas do LabFeed
        $screen = get_current_screen();
        if (!$screen || strpos($screen->id, 'labfeed') === false) {
            return;
        }

        $token = trim(get_option('labfeed_license_token', ''));
        if (!$token) {
            echo '<div class="notice notice-warning"><p><strong>LabFeed:</strong> Insira seu token para ativar o sistema.</p></div>';
            return;
        }

        $cache_key = 'labfeed_license_' . md5($token);
        $data = get_transient($cache_key);
        
        // Se não houver cache, valida agora
        if (!is_array($data)) {
            self::validate_remotely($token);
            $data = get_transient($cache_key) ?: [];
        }

        if (!empty($data['notice'])) {
            echo '<div class="notice notice-info is-dismissible"><p><strong>Aviso LabFeed:</strong> ' . wp_kses_post($data['notice']) . '</p></div>';
        }

        if (($data['status'] ?? '') !== 'active') {
            echo '<div class="notice notice-error"><p><strong>LabFeed:</strong> Licença inválida ou expirada. Verifique suas configurações.</p></div>';
            return;
        }

        if (!empty($data['expires_at'])) {
            $expires = strtotime($data['expires_at']);
            $days = ceil(($expires - time()) / DAY_IN_SECONDS);
            if ($days <= 0) {
                echo '<div class="notice notice-error"><p><strong>LabFeed:</strong> Sua licença expirou.</p></div>';
            } elseif ($days <= 7) {
                echo '<div class="notice notice-warning"><p><strong>LabFeed:</strong> Expira em ' . esc_html($days) . ' dias.</p></div>';
            }
        }
    }
}
