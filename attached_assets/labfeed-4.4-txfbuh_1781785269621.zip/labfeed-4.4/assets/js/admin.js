(function($) {
    'use strict';

    $(function() {
        // Copiar URL
        $(document).on('click', '.labfeed-copy-btn', function() {
            var $input = $(this).siblings('.labfeed-copy-input').length ? $(this).siblings('.labfeed-copy-input') : $(this).closest('.labfeed-url-field').find('.labfeed-copy-input');
            var url = $input.val() || $input.data('copy');
            if (url && navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(url).then(function() {
                    var $btn = $input.closest('.labfeed-url-field').find('.labfeed-copy-btn');
                    $btn.html('<span class="dashicons dashicons-yes"></span> Copiado!');
                    setTimeout(function() {
                        $btn.html('<span class="dashicons dashicons-clipboard"></span> Copiar');
                    }, 2000);
                });
            } else {
                $input.select();
                document.execCommand('copy');
            }
        });
        $('.labfeed-copy-input').on('click', function() {
            this.select();
        });

        // Página Novo Feed: validação de URL
        var $addPageForm = $('#labfeed-add-page-form');
        if ($addPageForm.length) {
            var $urlInput = $('#target_url');
            var $urlError = $('#labfeed-url-validation');
            var urlPattern = /^https?:\/\/.+/;
            function validateUrl() {
                var val = ($urlInput.val() || '').trim();
                if (!val) {
                    ($urlError.length ? $urlError : $addPageForm.find('.labfeed-err')).addClass('labfeed-hide').addClass('labfeed-hidden').text('');
                    return true;
                }
                if (!urlPattern.test(val) || !(function(u){ try { return !!new URL(u); } catch(e){ return false; } }(val))) {
                    var $err = $urlError.length ? $urlError : $addPageForm.find('.labfeed-err').first();
                    $err.removeClass('labfeed-hide').removeClass('labfeed-hidden').text(typeof labfeedAdmin !== 'undefined' && labfeedAdmin.i18n && labfeedAdmin.i18n.invalidUrl ? labfeedAdmin.i18n.invalidUrl : 'Informe uma URL válida.');
                    return false;
                }
                ($urlError.length ? $urlError : $addPageForm.find('.labfeed-err')).addClass('labfeed-hide').addClass('labfeed-hidden').text('');
                return true;
            }
            $urlInput.on('blur', validateUrl);
            $addPageForm.on('submit', function() {
                if (!validateUrl()) {
                    $urlInput.focus();
                    return false;
                }
            });
        }
    });
})(jQuery);
