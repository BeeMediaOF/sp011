<?php
if (!defined('ABSPATH')) exit;

$cache_minutes = get_option('labfeed_cache_minutes', 5);
$max_items     = get_option('labfeed_max_items', 20);
$license_token = get_option('labfeed_license_token', '');

// Obter info da licença para exibição
$license_info = $license_token
    ? get_transient('labfeed_license_' . md5($license_token))
    : false;

$license_expires_label = '';

if (is_array($license_info) && !empty($license_info['expires_at'])) {
    $license_expires_label = 'Válida até ' . date('d/m/Y', strtotime($license_info['expires_at']));
} elseif (is_array($license_info) && array_key_exists('expires_at', $license_info) && empty($license_info['expires_at'])) {
    $license_expires_label = 'Licença vitalícia';
}
?>

<div class="wrap labfeed-wrap">
    <h1>Configurações do LabFeed</h1>

    <form method="post" action="">
        <?php wp_nonce_field('labfeed_save_settings', 'labfeed_settings_nonce'); ?>
        
        <div class="card" style="max-width: 100%; margin-top: 20px; padding: 20px;">
            <h2>Licenciamento</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="license_token">Token de Ativação</label></th>
                    <td>
                        <input 
                            type="text" 
                            id="license_token" 
                            name="license_token" 
                            value="<?php echo esc_attr($license_token); ?>" 
                            class="regular-text" 
                            placeholder="Insira seu token"
                            required
                        >
                        <p class="description">
                            O token é obrigatório para liberar o funcionamento dos feeds. 
                            Adquira em <a href="https://pluginpress.com.br" target="_blank">pluginpress.com.br</a>.
                            <br><strong>Status:</strong>
                            <?php echo LabFeed_License::is_active()
                                ? '<span style="color:green">Ativo</span>'
                                : '<span style="color:red">Inativo</span>'; ?>

                            <?php if ($license_expires_label): ?>
                                <br><strong>Prazo:</strong> <?php echo esc_html($license_expires_label); ?>
                            <?php endif; ?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>

        <div class="card" style="max-width: 100%; margin-top: 20px; padding: 20px;">
            <h2>Geral</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="cache_minutes">Cache (minutos)</label></th>
                    <td>
                        <input 
                            type="number" 
                            id="cache_minutes" 
                            name="cache_minutes" 
                            value="<?php echo esc_attr($cache_minutes); ?>" 
                            class="small-text"
                            min="1"
                        >
                        <p class="description">Tempo de espera entre atualizações automáticas.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="max_items">Máximo de itens</label></th>
                    <td>
                        <input 
                            type="number" 
                            id="max_items" 
                            name="max_items" 
                            value="<?php echo esc_attr($max_items); ?>" 
                            class="small-text"
                            min="1"
                        >
                        <p class="description">Número máximo de itens por feed XML.</p>
                    </td>
                </tr>
            </table>
        </div>

        <p class="submit">
            <input type="submit" name="labfeed_settings" class="button button-primary" value="Salvar Configurações">
        </p>
    </form>
</div>