<?php
if (!defined('ABSPATH')) exit;
$page_title = __('LabFeed - Todos os Feeds', 'labfeed');
$logs = get_option('labfeed_logs', array());
if (!is_array($logs)) {
    $logs = array();
}
$has_logs = !empty($logs);
?>
<div class="wrap labfeed-wrap">
    <div class="labfeed-header">
        <h1 class="labfeed-title">
            <span class="dashicons dashicons-rss"></span>
            <?php echo esc_html($page_title); ?>
        </h1>
        <a href="<?php echo esc_url(admin_url('admin.php?page=labfeed-add')); ?>" class="page-title-action">
            <?php _e('Adicionar Feed', 'labfeed'); ?>
        </a>
        <?php if ($has_logs) : ?>
        <a href="<?php echo esc_url(admin_url('admin.php?page=labfeed-logs')); ?>" class="page-title-action" style="color:#d63638;">
            <span class="dashicons dashicons-warning" style="vertical-align:middle;font-size:18px;width:18px;height:18px;"></span>
            <?php printf(__('Ver logs (%d)', 'labfeed'), count($logs)); ?>
        </a>
        <?php endif; ?>
    </div>

    <div class="labfeed-dashboard-cards">
        <div class="labfeed-card labfeed-card-stats">
            <span class="labfeed-card-number"><?php echo count($links); ?></span>
            <span class="labfeed-card-label"><?php _e('Feeds cadastrados', 'labfeed'); ?></span>
        </div>
        <div class="labfeed-card labfeed-card-info">
            <p><?php _e('Os feeds são atualizados automaticamente a cada 5 minutos. Use as URLs na sua automação (Zapier, Make, etc).', 'labfeed'); ?></p>
        </div>
    </div>

    <?php if (!empty($links)) : ?>
    <div class="labfeed-table-card" id="labfeed-table-wrap">
        <table class="wp-list-table widefat fixed striped labfeed-table">
            <thead>
                <tr>
                    <th class="column-name"><?php _e('Feed', 'labfeed'); ?></th>
                    <th class="column-url"><?php _e('URL de origem', 'labfeed'); ?></th>
                    <th class="column-feed-url"><?php _e('URL do Feed XML', 'labfeed'); ?></th>
                    <th class="column-status"><?php _e('Status', 'labfeed'); ?></th>
                    <th class="column-actions"><?php _e('Ações', 'labfeed'); ?></th>
                </tr>
            </thead>
            <tbody id="labfeed-tbody">
                <?php foreach ($links as $link) :
                    $feed_url = home_url('/feed/labxml/?id=' . $link->id);
                    $last_check_ts = ($link->last_check && $link->last_check !== '0000-00-00 00:00:00') ? strtotime($link->last_check) : strtotime($link->last_update);
                    $last_check_label = ($last_check_ts > 0)
                        ? human_time_diff($last_check_ts, current_time('timestamp')) . ' ' . __('atrás', 'labfeed')
                        : __('Nunca', 'labfeed');
                    
                    $items_count = 0;
                    if (!empty($link->last_scraped)) {
                        $items = json_decode($link->last_scraped, true);
                        $items_count = is_array($items) ? count($items) : 0;
                    }
                    $has_error = !empty($link->last_error);
                ?>
                <tr>
                    <td class="column-name">
                        <strong><?php echo esc_html($link->site_name); ?></strong>
                    </td>
                    <td class="column-url">
                        <a href="<?php echo esc_url($link->target_url); ?>" target="_blank" rel="noopener">
                            <?php echo esc_html(wp_trim_words($link->target_url, 8)); ?>
                        </a>
                    </td>
                    <td class="column-feed-url">
                        <div class="labfeed-url-field">
                            <input type="text" readonly value="<?php echo esc_attr($feed_url); ?>" class="regular-text labfeed-copy-input" data-copy="<?php echo esc_attr($feed_url); ?>">
                            <button type="button" class="button button-small labfeed-copy-btn" title="<?php esc_attr_e('Copiar', 'labfeed'); ?>">
                                <span class="dashicons dashicons-clipboard"></span>
                            </button>
                        </div>
                    </td>
                    <td class="column-status">
                        <?php if ($has_error) : ?>
                            <span class="labfeed-status labfeed-status-error" title="<?php echo esc_attr($link->last_error); ?>">
                                <span class="dashicons dashicons-warning"></span>
                                <?php echo intval($items_count); ?> <?php _e('itens', 'labfeed'); ?>
                            </span>
                            <br><span class="description" style="color:#d63638;font-weight:500;"><?php _e('Falha na atualização', 'labfeed'); ?></span>
                            <br><span class="description"><?php echo esc_html($last_check_label); ?></span>
                        <?php elseif ($items_count > 0) : ?>
                            <span class="labfeed-status labfeed-status-ok">
                                <span class="dashicons dashicons-yes-alt"></span>
                                <?php echo intval($items_count); ?> <?php _e('itens', 'labfeed'); ?>
                            </span>
                            <br><span class="description"><?php echo esc_html($last_check_label); ?></span>
                        <?php else : ?>
                            <span class="labfeed-status labfeed-status-empty">
                                <span class="dashicons dashicons-warning"></span>
                                <?php _e('Nenhum item', 'labfeed'); ?>
                            </span>
                            <br><span class="description"><?php echo esc_html($last_check_label); ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="column-actions">
                        <a href="<?php echo esc_url($feed_url); ?>" target="_blank" rel="noopener" class="button button-small">
                            <?php _e('Ver XML', 'labfeed'); ?>
                        </a>
                        <a href="<?php echo esc_url($feed_url . '&force=1'); ?>" target="_blank" rel="noopener" class="button button-small">
                            <?php _e('Atualizar', 'labfeed'); ?>
                        </a>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=labfeed-edit&id=' . $link->id)); ?>" class="button button-small button-primary">
                            <?php _e('Editar', 'labfeed'); ?>
                        </a>
                        <a href="<?php echo esc_url(wp_nonce_url(add_query_arg('delete', $link->id, admin_url('admin.php?page=labfeed')), 'delete_link_' . $link->id)); ?>"
                           class="button button-small" style="color:#a00;"
                           onclick="return confirm('<?php echo esc_js(__('Excluir este feed?', 'labfeed')); ?>');">
                            <?php _e('Excluir', 'labfeed'); ?>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else : ?>
    <div class="labfeed-table-card" id="labfeed-table-wrap" style="display:none;">
        <table class="wp-list-table widefat fixed striped labfeed-table">
            <thead>
                <tr>
                    <th class="column-name"><?php _e('Feed', 'labfeed'); ?></th>
                    <th class="column-url"><?php _e('URL de origem', 'labfeed'); ?></th>
                    <th class="column-feed-url"><?php _e('URL do Feed XML', 'labfeed'); ?></th>
                    <th class="column-status"><?php _e('Status', 'labfeed'); ?></th>
                    <th class="column-actions"><?php _e('Ações', 'labfeed'); ?></th>
                </tr>
            </thead>
            <tbody id="labfeed-tbody"></tbody>
        </table>
    </div>
    <div class="labfeed-empty-state" id="labfeed-empty-state">
        <span class="dashicons dashicons-rss"></span>
        <h2><?php _e('Nenhum feed cadastrado', 'labfeed'); ?></h2>
        <p><?php _e('Adicione seu primeiro feed para transformar qualquer site em RSS.', 'labfeed'); ?></p>
        <a href="<?php echo esc_url(admin_url('admin.php?page=labfeed-add')); ?>" class="button button-primary button-hero">
            <?php _e('Adicionar Feed', 'labfeed'); ?>
        </a>
    </div>
    <?php endif; ?>

    <div class="labfeed-footer-card">
        <h3><?php _e('Como funciona', 'labfeed'); ?></h3>
        <ul>
            <li><strong>Scraper-to-RSS:</strong> <?php _e('Extrai automaticamente os links de notícias usando XPath.', 'labfeed'); ?></li>
            <li><strong><?php _e('Atualização automática:', 'labfeed'); ?></strong> <?php _e('Cron atualiza todos os feeds a cada 5 minutos.', 'labfeed'); ?></li>
            <li><strong><?php _e('Datas reais:', 'labfeed'); ?></strong> <?php _e('Preserva a data de publicação de cada post.', 'labfeed'); ?></li>
            <li><strong><?php _e('Compatível:', 'labfeed'); ?></strong> <?php _e('Revista Oeste, portais de notícias, blogs e sites sem RSS.', 'labfeed'); ?></li>
        </ul>
        <p class="labfeed-credit"><?php _e('Desenvolvido por', 'labfeed'); ?> <a href="https://pluginpress.com" target="_blank" rel="noopener">PluginPress</a></p>
    </div>
</div>
