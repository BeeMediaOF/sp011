<?php
if (!defined('ABSPATH')) exit;
$feed_url = home_url('/feed/labxml/?id=' . $feed->id);
?>
<div class="wrap labfeed-wrap labfeed-page-edit">
    <nav class="labfeed-breadcrumb" aria-label="<?php esc_attr_e('Navegação', 'labfeed'); ?>">
        <a href="<?php echo esc_url(admin_url('admin.php?page=labfeed')); ?>"><?php _e('LabFeed', 'labfeed'); ?></a>
        <span class="labfeed-breadcrumb-sep" aria-hidden="true">/</span>
        <span class="labfeed-breadcrumb-current"><?php echo esc_html($feed->site_name); ?></span>
    </nav>

    <header class="labfeed-page-header">
        <div class="labfeed-page-header-icon" aria-hidden="true">
            <span class="dashicons dashicons-edit"></span>
        </div>
        <div class="labfeed-page-header-text">
            <h1 class="labfeed-page-title"><?php _e('Editar feed', 'labfeed'); ?>: <?php echo esc_html($feed->site_name); ?></h1>
            <p class="labfeed-page-description"><?php _e('Altere os dados do feed. A URL do XML permanece a mesma após salvar.', 'labfeed'); ?></p>
        </div>
        <div class="labfeed-page-header-actions">
            <a href="<?php echo esc_url(admin_url('admin.php?page=labfeed')); ?>" class="button">
                <span class="dashicons dashicons-arrow-left-alt2" style="vertical-align:middle;margin-right:4px;"></span>
                <?php _e('Voltar à lista', 'labfeed'); ?>
            </a>
        </div>
    </header>

    <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=labfeed-edit&id=' . $feed->id)); ?>" id="labfeed-edit-form" class="labfeed-form-professional">
        <?php wp_nonce_field('update_feed_' . $feed->id); ?>

        <section class="labfeed-form-section" aria-labelledby="labfeed-edit-section-identification">
            <h2 id="labfeed-edit-section-identification" class="labfeed-section-title">
                <span class="labfeed-section-icon"><span class="dashicons dashicons-nametag"></span></span>
                <?php _e('Identificação', 'labfeed'); ?>
            </h2>
            <div class="labfeed-section-content">
                <div class="labfeed-field">
                    <label for="site_name" class="labfeed-label">
                        <?php _e('Nome do feed', 'labfeed'); ?> <span class="labfeed-required" aria-label="<?php esc_attr_e('Obrigatório', 'labfeed'); ?>">*</span>
                    </label>
                    <input type="text" id="site_name" name="site_name" class="labfeed-input labfeed-input-text" required
                           value="<?php echo esc_attr($feed->site_name); ?>">
                    <p class="labfeed-field-help"><?php _e('Nome interno no painel.', 'labfeed'); ?></p>
                </div>
            </div>
        </section>

        <section class="labfeed-form-section" aria-labelledby="labfeed-edit-section-origin">
            <h2 id="labfeed-edit-section-origin" class="labfeed-section-title">
                <span class="labfeed-section-icon"><span class="dashicons dashicons-admin-links"></span></span>
                <?php _e('URL de origem', 'labfeed'); ?>
            </h2>
            <div class="labfeed-section-content">
                <div class="labfeed-field">
                    <label for="target_url" class="labfeed-label">
                        <?php _e('URL do site ou página', 'labfeed'); ?> <span class="labfeed-required" aria-label="<?php esc_attr_e('Obrigatório', 'labfeed'); ?>">*</span>
                    </label>
                    <input type="url" id="target_url" name="target_url" class="labfeed-input labfeed-input-url" required
                           value="<?php echo esc_attr($feed->target_url); ?>">
                    <p class="labfeed-field-help"><?php _e('URL que será raspada para gerar o feed.', 'labfeed'); ?></p>
                </div>
            </div>
        </section>

        <div class="labfeed-form-actions">
            <button type="submit" name="update_feed" class="button button-primary button-hero">
                <span class="dashicons dashicons-saved" style="vertical-align:middle;margin-right:6px;"></span>
                <?php _e('Salvar alterações', 'labfeed'); ?>
            </button>
            <a href="<?php echo esc_url($feed_url); ?>" target="_blank" rel="noopener" class="button button-hero"><?php _e('Ver feed XML', 'labfeed'); ?></a>
            <a href="<?php echo esc_url($feed_url . '&force=1'); ?>" target="_blank" rel="noopener" class="button button-hero"><?php _e('Forçar atualização', 'labfeed'); ?></a>
        </div>
    </form>

    <section class="labfeed-form-section labfeed-url-section" aria-labelledby="labfeed-edit-url-title">
        <h2 id="labfeed-edit-url-title" class="labfeed-section-title">
            <span class="labfeed-section-icon"><span class="dashicons dashicons-admin-site-alt3"></span></span>
            <?php _e('URL do feed (para copiar)', 'labfeed'); ?>
        </h2>
        <div class="labfeed-section-content">
            <div class="labfeed-url-field labfeed-url-field-large">
                <input type="text" readonly value="<?php echo esc_attr($feed_url); ?>" class="labfeed-input labfeed-copy-input" data-copy="<?php echo esc_attr($feed_url); ?>">
                <button type="button" class="button labfeed-copy-btn">
                    <span class="dashicons dashicons-clipboard"></span> <?php _e('Copiar', 'labfeed'); ?>
                </button>
            </div>
        </div>
    </section>
</div>
