<?php
if (!defined('ABSPATH')) exit;
if (!isset($logs) || !is_array($logs)) {
    $logs = array();
}
$type_labels = array(
    'fetch_error' => __('Erro ao acessar', 'labfeed'),
    'retry_failed' => __('Retry falhou', 'labfeed'),
    'retry_ok' => __('Retry OK', 'labfeed'),
    'stream_failed' => __('Fallback falhou', 'labfeed'),
    'stream_ok' => __('Fallback OK', 'labfeed'),
    'anti_scrap' => __('Anti-scrap/Cloudflare', 'labfeed'),
    'no_content' => __('Resposta vazia', 'labfeed'),
    'no_posts' => __('Nenhum post encontrado', 'labfeed'),
);
$type_classes = array(
    'fetch_error' => 'error',
    'retry_failed' => 'error',
    'stream_failed' => 'error',
    'no_content' => 'error',
    'anti_scrap' => 'warning',
    'no_posts' => 'warning',
    'retry_ok' => 'info',
    'stream_ok' => 'info',
);
?>
<div class="wrap labfeed-wrap">
    <h1 class="wp-heading-inline"><?php _e('Logs do LabFeed', 'labfeed'); ?></h1>
    <?php if (!empty($logs)) : ?>
    <a href="<?php echo esc_url(wp_nonce_url(add_query_arg('labfeed_clear_logs', '1', admin_url('admin.php?page=labfeed-logs')), 'labfeed_clear_logs')); ?>" class="page-title-action"><?php _e('Limpar logs', 'labfeed'); ?></a>
    <?php endif; ?>
    <hr class="wp-header-end">

    <p class="labfeed-logs-desc"><?php _e('Registro de erros e avisos: bloqueios, anti-scrap, sites inacessíveis, nenhum post encontrado.', 'labfeed'); ?></p>

    <?php if (empty($logs)) : ?>
    <div class="labfeed-logs-empty">
        <span class="dashicons dashicons-yes-alt"></span>
        <p><?php _e('Nenhum log registrado. Os logs aparecem quando um feed falha ao buscar conteúdo.', 'labfeed'); ?></p>
    </div>
    <?php else : ?>
    <table class="wp-list-table widefat fixed striped labfeed-logs-table">
        <thead>
            <tr>
                <th class="column-date" style="width:140px;"><?php _e('Data/Hora', 'labfeed'); ?></th>
                <th class="column-type" style="width:160px;"><?php _e('Tipo', 'labfeed'); ?></th>
                <th class="column-url"><?php _e('URL', 'labfeed'); ?></th>
                <th class="column-message"><?php _e('Mensagem', 'labfeed'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($logs as $entry) :
                $type = isset($entry['type']) ? $entry['type'] : '';
                $label = isset($type_labels[$type]) ? $type_labels[$type] : $type;
                $class = isset($type_classes[$type]) ? $type_classes[$type] : 'info';
                $msg = isset($entry['message']) ? esc_html($entry['message']) : '';
                $details = isset($entry['details']) && is_array($entry['details']) ? $entry['details'] : array();
                if (!empty($details)) {
                    $extra = array();
                    if (isset($details['error'])) {
                        $extra[] = esc_html($details['error']);
                    }
                    if (isset($details['code'])) {
                        $extra[] = 'HTTP ' . intval($details['code']);
                    }
                    if (isset($details['html_len'])) {
                        $extra[] = sprintf(__('%d bytes', 'labfeed'), intval($details['html_len']));
                    }
                    if (!empty($extra)) {
                        $msg .= ' (' . implode(', ', $extra) . ')';
                    }
                }
            ?>
            <tr class="labfeed-log-row labfeed-log-<?php echo esc_attr($class); ?>">
                <td class="column-date"><?php echo esc_html(isset($entry['ts']) ? $entry['ts'] : '-'); ?></td>
                <td class="column-type"><span class="labfeed-log-badge labfeed-log-badge-<?php echo esc_attr($class); ?>"><?php echo esc_html($label); ?></span></td>
                <td class="column-url"><?php
                $raw_url = isset($entry['url']) ? $entry['url'] : '';
                if ($raw_url) {
                    echo '<a href="' . esc_url($raw_url) . '" target="_blank" rel="noopener">' . esc_html(wp_trim_words($raw_url, 14)) . '</a>';
                } else {
                    echo '-';
                }
            ?></td>
                <td class="column-message"><?php echo $msg; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
