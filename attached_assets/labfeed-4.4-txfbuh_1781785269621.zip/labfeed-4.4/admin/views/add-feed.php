<?php
if (!defined('ABSPATH')) exit;
$has_errors = isset($labfeed_form_error) && $labfeed_form_error;
?>
<div class="wrap labfeed-wrap labfeed-page-add">
    <nav class="labfeed-breadcrumb" aria-label="<?php esc_attr_e('Navegação', 'labfeed'); ?>">
        <a href="<?php echo esc_url(admin_url('admin.php?page=labfeed')); ?>"><?php _e('LabFeed', 'labfeed'); ?></a>
        <span class="labfeed-breadcrumb-sep" aria-hidden="true">/</span>
        <span class="labfeed-breadcrumb-current"><?php _e('Novo Feed', 'labfeed'); ?></span>
    </nav>

    <header class="labfeed-page-header">
        <div class="labfeed-page-header-icon" aria-hidden="true">
            <span class="dashicons dashicons-plus-alt2"></span>
        </div>
        <div class="labfeed-page-header-text">
            <h1 class="labfeed-page-title"><?php _e('Cadastrar novo feed', 'labfeed'); ?></h1>
            <p class="labfeed-page-description"><?php _e('Transforme qualquer página web em um feed RSS. Informe a URL de origem.', 'labfeed'); ?></p>
        </div>
        <div class="labfeed-page-header-actions">
            <a href="<?php echo esc_url(admin_url('admin.php?page=labfeed')); ?>" class="button">
                <span class="dashicons dashicons-arrow-left-alt2" style="vertical-align:middle;margin-right:4px;"></span>
                <?php _e('Voltar à lista', 'labfeed'); ?>
            </a>
        </div>
    </header>

    <?php if ($has_errors && !empty($labfeed_form_error)) : ?>
    <div class="labfeed-notice labfeed-notice-error" role="alert">
        <span class="dashicons dashicons-warning"></span>
        <p><?php echo esc_html($labfeed_form_error); ?></p>
    </div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=labfeed-add')); ?>" id="labfeed-add-page-form" class="labfeed-form-professional">
        <?php wp_nonce_field('save_link'); ?>

        <section class="labfeed-form-section" aria-labelledby="labfeed-section-identification">
            <h2 id="labfeed-section-identification" class="labfeed-section-title">
                <span class="labfeed-section-icon"><span class="dashicons dashicons-nametag"></span></span>
                <?php _e('Identificação', 'labfeed'); ?>
            </h2>
            <div class="labfeed-section-content">
                <div class="labfeed-field">
                    <label for="site_name" class="labfeed-label">
                        <?php _e('Nome do feed', 'labfeed'); ?> <span class="labfeed-required" aria-label="<?php esc_attr_e('Obrigatório', 'labfeed'); ?>">*</span>
                    </label>
                    <input type="text" id="site_name" name="site_name" class="labfeed-input labfeed-input-text" required
                           placeholder="<?php esc_attr_e('Ex: Revista Oeste - Política', 'labfeed'); ?>"
                           value="<?php echo esc_attr(isset($_POST['site_name']) ? sanitize_text_field(wp_unslash($_POST['site_name'])) : ''); ?>"
                           autocomplete="off">
                    <p class="labfeed-field-help"><?php _e('Nome interno para identificar este feed no painel. Não aparece no XML.', 'labfeed'); ?></p>
                </div>
            </div>
        </section>

        <section class="labfeed-form-section" aria-labelledby="labfeed-section-origin">
            <h2 id="labfeed-section-origin" class="labfeed-section-title">
                <span class="labfeed-section-icon"><span class="dashicons dashicons-admin-links"></span></span>
                <?php _e('URL de origem', 'labfeed'); ?>
            </h2>
            <div class="labfeed-section-content">
                <div class="labfeed-field">
                    <label for="target_url" class="labfeed-label">
                        <?php _e('URL do site ou página', 'labfeed'); ?> <span class="labfeed-required" aria-label="<?php esc_attr_e('Obrigatório', 'labfeed'); ?>">*</span>
                    </label>
                    <input type="url" id="target_url" name="target_url" class="labfeed-input labfeed-input-url" required
                           placeholder="https://exemplo.com/secao/"
                           value="<?php echo esc_attr(isset($_POST['target_url']) ? esc_url_raw(wp_unslash($_POST['target_url'])) : ''); ?>"
                           autocomplete="url">
                    <p class="labfeed-field-help"><?php _e('Cole a URL completa da página que deseja transformar em RSS (categoria, seção ou homepage).', 'labfeed'); ?></p>
                    <p id="labfeed-url-validation" class="labfeed-field-error labfeed-hidden" role="alert"></p>
                </div>
            </div>
        </section>

        <div class="labfeed-form-actions">
            <button type="submit" name="save_link" class="button button-primary button-hero labfeed-btn-submit">
                <span class="dashicons dashicons-saved" style="vertical-align:middle;margin-right:6px;"></span>
                <?php _e('Cadastrar e gerar feed', 'labfeed'); ?>
            </button>
            <a href="<?php echo esc_url(admin_url('admin.php?page=labfeed')); ?>" class="button button-hero"><?php _e('Cancelar', 'labfeed'); ?></a>
        </div>
    </form>

    <aside class="labfeed-side-note">
        <span class="dashicons dashicons-info"></span>
        <p><?php _e('Após o cadastro, o feed será atualizado automaticamente a cada 5 minutos. Você poderá copiar a URL do XML na lista de feeds.', 'labfeed'); ?></p>
    </aside>
</div>
