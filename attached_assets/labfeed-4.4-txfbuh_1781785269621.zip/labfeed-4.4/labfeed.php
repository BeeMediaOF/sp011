<?php
/**
 * Plugin Name: LabFeed - Link to XML Converter
 * Plugin URI: https://pluginpress.com
 * Description: Transforma qualquer link de site em um feed XML (RSS) via raspagem automática. Converte sites sem RSS em feeds estruturados para automação.
 * Version: 4.4.0
 * Author: PluginPress
 * Author URI: https://pluginpress.com
 * Text Domain: labfeed
 */

if (!defined('ABSPATH')) exit;

// Incluir sistema de licenciamento
require_once plugin_dir_path(__FILE__) . 'includes/class-labfeed-license.php';

class LabFeedConverter {
    private $cron_hook = 'labfeed_auto_update';
    
    public function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        add_action('init', array($this, 'register_feed_endpoint'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'admin_assets'));
        
        // Aviso de licença
        add_action('admin_notices', array('LabFeed_License', 'render_activation_notice'));
        add_action('admin_notices', array($this, 'render_430_install_notice'));

        // Sistema de atualização automática
        add_action($this->cron_hook, array($this, 'auto_update_feeds'));
        add_action('admin_init', array($this, 'schedule_auto_update'));
        add_action('admin_init', array($this, 'maybe_run_migration'));
        add_filter('cron_schedules', array($this, 'add_cron_interval'));
        add_action('wp_ajax_labfeed_add_feed', array($this, 'ajax_add_feed'));
    }

    public function activate() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'labfeed_links';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            site_name varchar(255) NOT NULL,
            target_url varchar(500) NOT NULL,
            feed_title varchar(255) DEFAULT '',
            feed_description text,
            last_scraped longtext,
            last_update datetime DEFAULT '0000-00-00 00:00:00',
            last_check datetime DEFAULT '0000-00-00 00:00:00',
            last_error text,
            options longtext,
            PRIMARY KEY  (id),
            KEY target_url (target_url(191))
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Registrar endpoint de feed
        add_feed('labxml', array($this, 'generate_xml_output'));
        
        // Agendar atualização automática
        $this->schedule_auto_update();
        
        // Marcar como versão 5
        update_option('labfeed_db_version', 5);
        
        flush_rewrite_rules();

        // Aviso para quem instala 4.4.0: substituir versão anterior e evitar erro fatal
        set_transient('labfeed_430_replace_notice', '1', 7 * DAY_IN_SECONDS);
    }

    /**
     * Exibe aviso único após instalar/ativar 4.4.0: substituir pasta do plugin anterior para evitar erro fatal.
     */
    public function render_430_install_notice() {
        if (!current_user_can('activate_plugins')) {
            return;
        }
        if (get_transient('labfeed_430_replace_notice') !== '1') {
            return;
        }
        $dismiss_url = wp_nonce_url(add_query_arg('labfeed_430_dismiss', '1', admin_url('admin.php?page=labfeed')), 'labfeed_430_dismiss');
        ?>
        <div class="notice notice-warning is-dismissible">
            <p><strong>LabFeed 4.4.0</strong> — <?php _e('Para evitar erro fatal na instalação ou atualização, substitua completamente a pasta do plugin anterior por esta versão. Desative a versão antiga antes de ativar a nova.', 'labfeed'); ?></p>
            <p><a href="<?php echo esc_url($dismiss_url); ?>"><?php _e('Entendi, não mostrar de novo', 'labfeed'); ?></a></p>
        </div>
        <?php
    }

    public function deactivate() {
        // Remover cron job ao desativar
        $timestamp = wp_next_scheduled($this->cron_hook);
        if ($timestamp) {
            wp_unschedule_event($timestamp, $this->cron_hook);
        }
        flush_rewrite_rules();
    }

    /**
     * Agenda atualização automática a cada 5 minutos
     */
    public function schedule_auto_update() {
        if (!wp_next_scheduled($this->cron_hook)) {
            wp_schedule_event(time(), 'labfeed_5min', $this->cron_hook);
        }
    }

    /**
     * Migração: garante que colunas feed_title, feed_description e options existam
     */
    public function maybe_run_migration() {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }
        
        $current_version = intval(get_option('labfeed_db_version', 0));
        if ($current_version >= 5) {
            return;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'labfeed_links';
        
        // dbDelta no admin_init para garantir esquema atualizado se falhou na ativação
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            site_name varchar(255) NOT NULL,
            target_url varchar(500) NOT NULL,
            feed_title varchar(255) DEFAULT '',
            feed_description text,
            last_scraped longtext,
            last_update datetime DEFAULT '0000-00-00 00:00:00',
            last_check datetime DEFAULT '0000-00-00 00:00:00',
            last_error text,
            options longtext,
            PRIMARY KEY  (id),
            KEY target_url (target_url(191))
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        update_option('labfeed_db_version', 5);
    }

    /**
     * Adiciona intervalo personalizado de 5 minutos
     */
    public function add_cron_interval($schedules) {
        $schedules['labfeed_5min'] = array(
            'interval' => 300, // 5 minutos
            'display' => __('A cada 5 minutos', 'labfeed')
        );
        return $schedules;
    }

    /**
     * Atualiza automaticamente todos os feeds cadastrados
     */
    public function auto_update_feeds() {
        // Bloquear se a licença não estiver ativa
        if (!LabFeed_License::is_active()) {
            return;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'labfeed_links';
        
        // Buscar feeds em lotes de 8 por vez, priorizando os que não são verificados há mais tempo
        $links = $wpdb->get_results("SELECT id, target_url FROM $table_name ORDER BY last_check ASC LIMIT 8");
        if (!is_array($links)) {
            $links = array();
        }
        if (empty($links)) {
            return;
        }

        foreach ($links as $link) {
            $current_time = current_time('mysql');
            try {
                // Tenta raspar
                $items = $this->scrape_target_site($link->target_url);
                
                // Sucesso: atualiza itens, data de atualização (sucesso) e limpa erro
                $wpdb->update(
                    $table_name,
                    array(
                        'last_scraped' => json_encode($items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        'last_update'  => $current_time,
                        'last_check'   => $current_time,
                        'last_error'   => null
                    ),
                    array('id' => $link->id),
                    array('%s', '%s', '%s', '%s'),
                    array('%d')
                );
            } catch (Exception $e) {
                // Erro: loga erro e atualiza apenas last_check e last_error
                error_log('LabFeed Error: ' . $e->getMessage());
                $this->push_log('fetch_error', $link->target_url, $e->getMessage(), array());

                $wpdb->update(
                    $table_name,
                    array(
                        'last_check' => $current_time,
                        'last_error' => $e->getMessage()
                    ),
                    array('id' => $link->id),
                    array('%s', '%s'),
                    array('%d')
                );
            }
        }
    }

    /**
     * Registra uma entrada nos logs do painel (erros, avisos). Mantém no máximo 200 entradas.
     */
    private function push_log($type, $url, $message, $details = array()) {
        $logs = get_option('labfeed_logs', array());
        if (!is_array($logs)) {
            $logs = array();
        }
        $logs[] = array(
            'type'    => $type,
            'url'     => $url,
            'message' => $message,
            'details' => $details,
            'ts'      => current_time('Y-m-d H:i:s')
        );
        $logs = array_slice($logs, -200, 200);
        update_option('labfeed_logs', $logs);
    }

    public function register_feed_endpoint() {
        add_feed('labxml', array($this, 'generate_xml_output'));
    }

    public function generate_xml_output() {
        // Bloquear se a licença não estiver ativa
        if (!LabFeed_License::is_active()) {
            status_header(403);
            wp_die('Licença LabFeed inativa. Ative o plugin no painel administrativo para liberar os feeds.', 'Acesso Proibido', array('response' => 403));
        }

        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        
        if (!$id) {
            status_header(400);
            wp_die('ID do link não fornecido.', 'Erro no Pedido', array('response' => 400));
        }

        global $wpdb;
        $link_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}labfeed_links WHERE id = %d", $id));
        
        if (!$link_data) {
            status_header(404);
            wp_die('Link não encontrado.', 'Não Encontrado', array('response' => 404));
        }

        // Realizar raspagem em tempo real ou usar cache (5 minutos para melhor atualização)
        $now = current_time('timestamp');
        $last_update = $link_data->last_update && $link_data->last_update !== '0000-00-00 00:00:00' 
            ? strtotime($link_data->last_update) 
            : 0;
        
        $cache_time = 300; // 5 minutos
        $force_update = isset($_GET['force']);
        
        if (($now - $last_update) > $cache_time || empty($link_data->last_scraped) || $force_update) {
            $items        = array();
            $cached_items = array();

            if (!empty($link_data->last_scraped)) {
                $cached_items = json_decode($link_data->last_scraped, true);
                if (!is_array($cached_items)) {
                    $cached_items = array();
                }
            }

            try {
                $items = $this->scrape_target_site($link_data->target_url);

                $wpdb->update(
                    $wpdb->prefix . 'labfeed_links',
                    array(
                        'last_scraped' => json_encode($items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        'last_update'  => current_time('mysql'),
                        'last_check'   => current_time('mysql'),
                        'last_error'   => null
                    ),
                    array('id' => $id),
                    array('%s', '%s', '%s', '%s'),
                    array('%d')
                );
            } catch (Exception $e) {
                error_log('LabFeed Error (generate_xml_output): ' . $e->getMessage());
                $this->push_log('fetch_error', $link_data->target_url, $e->getMessage(), array());

                if (!empty($cached_items)) {
                    $items = $cached_items;
                } else {
                    $items = array();
                }

                $wpdb->update(
                    $wpdb->prefix . 'labfeed_links',
                    array(
                        'last_check' => current_time('mysql'),
                        'last_error' => $e->getMessage()
                    ),
                    array('id' => $id),
                    array('%s', '%s'),
                    array('%d')
                );
            }
        } else {
            $items = json_decode($link_data->last_scraped, true);
            if (!is_array($items)) {
                $items = array();
            }
        }

        // Filtrar: itens com data válida (preferir 24h, senão 7 dias); itens sem data entram com data sintética
        $now_ts     = current_time('timestamp');
        $cutoff_24h = $now_ts - 86400;
        $cutoff_7d  = $now_ts - 7 * 86400;
        $with_date  = array_filter($items, function ($item) {
            if (empty($item['pub_date']) || !is_string($item['pub_date'])) return false;
            $ts = strtotime($item['pub_date']);
            return $ts !== false && $ts >= 0;
        });
        $no_date = array_values(array_filter($items, function ($item) {
            return empty($item['pub_date']) || !is_string($item['pub_date']) || strtotime($item['pub_date']) === false;
        }));
        $items_24h = array_filter($with_date, function ($item) use ($cutoff_24h) {
            return strtotime($item['pub_date']) >= $cutoff_24h;
        });
        $items_7d = array_filter($with_date, function ($item) use ($cutoff_7d) {
            return strtotime($item['pub_date']) >= $cutoff_7d;
        });
        $items = !empty($items_24h) ? array_values($items_24h) : array_values($items_7d);
        // Incluir itens sem data com data sintética (evitar feed vazio em sites que não expõem data)
        $max_undated = 20;
        foreach (array_slice($no_date, 0, $max_undated) as $i => $item) {
            $item['pub_date'] = date('Y-m-d H:i:s', $now_ts - ($i * 60));
            $items[] = $item;
        }

        // Ordenar em ordem decrescente (mais recente primeiro)
        usort($items, function ($a, $b) {
            $ts_a = !empty($a['pub_date']) ? strtotime($a['pub_date']) : 0;
            $ts_b = !empty($b['pub_date']) ? strtotime($b['pub_date']) : 0;
            return $ts_b - $ts_a;
        });

        // Evitar "horas iguais": espalhar timestamps duplicados (adicionar 1 minuto por duplicata)
        $items = $this->spread_duplicate_pub_dates($items);

        // Nunca exibir data futura (ex.: data no título interpretada como data de post)
        foreach ($items as &$it) {
            if (!empty($it['pub_date']) && is_string($it['pub_date'])) {
                $ts = strtotime($it['pub_date']);
                if ($ts !== false && $ts > $now_ts) {
                    $it['pub_date'] = date('Y-m-d H:i:s', $now_ts);
                }
            }
        }
        unset($it);

        // Gerar o XML puro
        if (ob_get_length()) {
            ob_clean();
        }
        
        // Headers para RSS
        header('Content-Type: application/rss+xml; charset=utf-8', true);
        header('X-Content-Type-Options: nosniff', true);
        
        // Gerar XML
        $feed_url = home_url('/feed/labxml/?id=' . $id);
        echo '<?xml version="1.0" encoding="utf-8"?>' . "\n";
        ?>
<rss version="2.0" xml:base="<?php echo esc_url($feed_url); ?>" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:sy="http://purl.org/rss/1.0/modules/syndication/">
    <channel>
        <title><?php echo esc_xml($link_data->site_name); ?></title>
        <link><?php echo esc_url($feed_url); ?></link>
        <description><?php echo esc_xml('Feed XML gerado automaticamente pelo LabFeed a partir de: ' . $link_data->target_url); ?></description>
        <language>pt-br</language>
        <atom:link href="<?php echo esc_url($feed_url); ?>" rel="self" type="application/rss+xml" />
        
        <?php if (!empty($items) && is_array($items)) : 
            foreach ($items as $item) : 
                if (empty($item['title']) || empty($item['link'])) continue;
                $parsed_link = parse_url($item['link']);
                $link_domain = (isset($parsed_link['scheme']) && isset($parsed_link['host'])) ? $parsed_link['scheme'] . '://' . $parsed_link['host'] : $link_data->target_url;
                $guid = md5($item['link'] . $item['title']) . ' at ' . $link_domain;
                
                $pub_date = !empty($item['pub_date']) ? $item['pub_date'] : date('D, d M Y H:i:s O');
                $author = !empty($item['author']) ? $item['author'] : '';
                ?>
        <item>
            <title><?php echo esc_xml($item['title']); ?></title>
            <link><?php echo esc_url($item['link']); ?></link>
            <guid isPermaLink="false"><?php echo esc_xml($guid); ?></guid>
            <pubDate><?php echo date('D, d M Y H:i:s O', strtotime($pub_date)); ?></pubDate>
            <?php if (!empty($author)) : ?>
            <dc:creator><![CDATA[<?php echo esc_xml($author); ?>]]></dc:creator>
            <?php endif; ?>
            <description><![CDATA[<?php echo !empty($item['description']) ? $item['description'] : ''; ?>]]></description>
            <content:encoded><![CDATA[<?php echo !empty($item['description']) ? $item['description'] : ''; ?>]]></content:encoded>
        </item>
                <?php
            endforeach;
        endif; ?>
    </channel>
</rss>
        <?php
        exit;
    }

    /**
     * Espalha itens com o mesmo pub_date para evitar "horas iguais" no feed.
     * Mantém a ordem; duplicatas recebem 1 minuto a menos cada.
     */
    private function spread_duplicate_pub_dates($items) {
        if (empty($items)) return $items;
        $by_ts = array();
        foreach ($items as $i => $item) {
            $ts = !empty($item['pub_date']) ? strtotime($item['pub_date']) : 0;
            if (!isset($by_ts[$ts])) $by_ts[$ts] = 0;
            $by_ts[$ts]++;
        }
        $offset = 0;
        foreach ($items as $i => &$item) {
            $ts = !empty($item['pub_date']) ? strtotime($item['pub_date']) : 0;
            if ($ts > 0 && $by_ts[$ts] > 1) {
                $item['pub_date'] = date('Y-m-d H:i:s', $ts - ($offset * 60));
                $offset++;
                $by_ts[$ts]--;
                if ($by_ts[$ts] <= 0) $offset = 0;
            }
        }
        unset($item);
        return $items;
    }

    /**
     * Retorna lista de XPath para descobrir links de notícias. Inclui seletores
     * específicos por domínio quando reconhecido (Rolandia, PMVC, RJ, Revista Oeste, etc).
     */
    private function get_link_queries_for_url($url) {
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        $site_specific = array();

        if (strpos($host, 'rolandia.pr.gov.br') !== false || (strpos($host, 'rolandia') !== false && strpos($host, 'gov') !== false)) {
            $site_specific = array(
                "//a[contains(@href,'noticias_individual') or contains(@href,'noticia') or contains(@href,'noticias')]",
                "//div[contains(@class,'noticia')]//a[@href]",
                "//*[contains(@class,'item-noticia') or contains(@class,'noticia')]//a[@href]",
                "//main//a[@href][contains(@href,'/noticia') or contains(@href,'noticias')]",
                "//section//a[@href][contains(@href,'noticia')]",
                "//article//a[@href]",
                "//a[contains(@href,'.php') or contains(@href,'.asp')][string-length(normalize-space(.)) > 15]",
            );
        }
        if (strpos($host, 'pmvc.ba.gov.br') !== false) {
            $site_specific = array(
                "//main//a[@href][not(contains(@href,'/categoria/'))][not(contains(@href,'/secretaria/'))]",
                "//article//a[@href]",
                "//div[contains(@class,'listagem')]//a[@href][not(contains(@href,'/categoria/'))]",
            );
        }
        if (strpos($host, 'guarulhos.sp.gov.br') !== false) {
            $site_specific = array(
                "//td[contains(@class,'views-field-title')]//a[@href]",
                "//div[contains(@class,'views-field-title')]//a[@href]",
            );
        }
        if (strpos($host, 'rj.gov.br') !== false) {
            $site_specific = array(
                "//a[contains(@href,'/noticias/') or contains(@href,'/noticia/') or contains(@href,'noticias') or contains(@href,'noticia')]",
                "//article//a[@href]",
                "//main//a[@href][string-length(normalize-space(.)) > 15]",
                "//div[contains(@class,'noticia') or contains(@class,'card') or contains(@class,'item') or contains(@class,'materia')]//a[@href]",
                "//*[contains(@class,'listagem') or contains(@class,'lista-noticias') or contains(@class,'content')]//a[@href][string-length(normalize-space(.)) > 20]",
                "//a[@href][contains(@href,'rj.gov.br') and string-length(normalize-space(.)) > 25]",
            );
        }
        if (strpos($host, 'revistaoeste.com') !== false || strpos($host, 'achouquetop.com') !== false) {
            $site_specific = array(
                "//article//a[@href]",
                "//a[contains(@href,'/politica/') or contains(@href,'/economia/') or contains(@href,'/mundo/') or contains(@href,'/cultura/')]",
                "//main//a[@href][string-length(normalize-space(.)) > 25]",
                "//div[contains(@class,'post') or contains(@class,'entry') or contains(@class,'card')]//a[@href]",
            );
        }
        if (strpos($host, 'maisnovela.com.br') !== false) {
            $site_specific = array(
                "//a[contains(@href,'.phtml')][string-length(normalize-space(.)) > 20]",
                "//article//a[@href][contains(@href,'.phtml')]",
                "//main//a[contains(@href,'/bbb/') and contains(@href,'.phtml')]",
            );
        }

        $generic = array(
            "//article//a[@href]",
            "//main//a[@href]",
            "//div[contains(@class, 'post')]//a[@href]",
            "//div[contains(@class, 'entry')]//a[@href]",
            "//div[contains(@class, 'item')]//a[@href]",
            "//div[contains(@class, 'noticia')]//a[@href]",
            "//div[contains(@class, 'materia')]//a[@href]",
            "//a[contains(@class, 'link') and @href]"
        );

        return array_merge($site_specific, $generic);
    }

    /**
     * Fallback: extrai links do HTML bruto quando o XPath não encontra itens (páginas minimalistas ou JS).
     * Filtra por padrões de URL que parecem artigos (noticias, politica, slugs, etc.).
     */
    private function extract_links_from_raw_html($html, $base_url) {
        $items = array();
        $seen = array();
        $base_host = strtolower((string) parse_url($base_url, PHP_URL_HOST));
        $irrelevant = array('contato', 'sobre', 'anuncie', 'privacidade', 'termos', 'login', 'register', 'autor', 'author', '#', 'javascript:');
        // Padrões de path que costumam ser artigos (por domínio)
        $article_path_patterns = array(
            'rj.gov.br' => array('noticias', 'noticia'),
            'revistaoeste.com' => array('politica', 'economia', 'mundo', 'cultura', 'brasil', 'entrevista'),
            'achouquetop.com' => array('politica', 'economia', 'mundo', 'cultura'),
            'rolandia' => array('noticia', 'noticias'),
            'guarulhos' => array('artigo'),
        );
        if (preg_match_all('/\bhref\s*=\s*["\']([^"\']+)["\']/i', $html, $m)) {
            foreach ($m[1] as $href) {
                $href = trim($href);
                if ($href === '' || strpos($href, '#') === 0 || stripos($href, 'javascript:') === 0) {
                    continue;
                }
                $absolute = $this->make_absolute_url($href, $base_url);
                if ($this->is_non_html_resource_link($absolute)) {
                    continue;
                }
                if (!$this->is_allowed_article_link_for_host($absolute, $base_url)) {
                    continue;
                }
                $host = strtolower((string) parse_url($absolute, PHP_URL_HOST));
                if ($host !== $base_host) {
                    continue;
                }
                $path = (string) parse_url($absolute, PHP_URL_PATH);
                $path_lower = strtolower($path);
                $skip = false;
                foreach ($irrelevant as $kw) {
                    if (strpos($path_lower, $kw) !== false) {
                        $skip = true;
                        break;
                    }
                }
                if ($skip || in_array($absolute, $seen)) {
                    continue;
                }
                $matches_article = false;
                foreach ($article_path_patterns as $domain_part => $patterns) {
                    if (strpos($base_host, $domain_part) !== false) {
                        foreach ($patterns as $p) {
                            if (strpos($path_lower, $p) !== false) {
                                $matches_article = true;
                                break 2;
                            }
                        }
                    }
                }
                if (!$matches_article) {
                    if (strpos($path_lower, 'noticia') !== false || strpos($path_lower, 'post') !== false
                        || preg_match('#/[0-9]{4}/[0-9]{2}/#', $path) || preg_match('#/[a-z0-9-]+-[0-9]+#', $path)) {
                        $matches_article = true;
                    }
                }
                if (!$matches_article || strlen($path) < 5) {
                    continue;
                }
                $title = trim(urldecode(basename(rtrim($path, '/'))));
                if (strlen($title) < 3) {
                    $title = __('Notícia', 'labfeed');
                }
                $title = preg_replace('/[-_]/', ' ', $title);
                $title = $this->strip_duplicate_category_prefix($title);
                if (strlen($title) > 120) {
                    $title = substr($title, 0, 117) . '...';
                }
                $items[] = array(
                    'title' => $title,
                    'link' => $absolute,
                    'description' => '',
                    'pub_date' => '',
                    'author' => ''
                );
                $seen[] = $absolute;
                if (count($items) >= 50) {
                    break;
                }
            }
        }
        return $items;
    }

    /**
     * Timeout em segundos para a raspagem; domínios lentos ou pesados recebem mais tempo.
     */
    private function get_scrape_timeout($url) {
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if (strpos($host, 'revistaoeste.com') !== false || strpos($host, 'achouquetop.com') !== false
            || strpos($host, 'rj.gov.br') !== false) {
            return 50;
        }
        return 30;
    }

    /**
     * Gera um Referer base do domínio para reduzir bloqueios anti-bot em alguns portais.
     */
    private function get_site_referer($url) {
        $scheme = (string) parse_url($url, PHP_URL_SCHEME);
        $host   = (string) parse_url($url, PHP_URL_HOST);
        if ($scheme === '' || $host === '') {
            return '';
        }
        return $scheme . '://' . $host . '/';
    }

    /**
     * Realiza a raspagem do site alvo
     */
    private function scrape_target_site($url) {
        $response = wp_remote_get($url, array(
            'timeout' => $this->get_scrape_timeout($url),
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'headers' => array(
                'Referer' => $this->get_site_referer($url),
                'Accept-Language' => 'pt-BR,pt;q=0.9,en;q=0.8'
            ),
            'sslverify' => false
        ));

        if (is_wp_error($response)) {
            throw new Exception($response->get_error_message());
        }

        $html = wp_remote_retrieve_body($response);
        $res = wp_remote_retrieve_response_code($response);
        
        if ($res !== 200) {
            $msg = ($res == 403) ? __('Servidor bloqueou o acesso (HTTP 403 - proibido).', 'labfeed')
                : sprintf(__('Erro ao acessar site (HTTP %d).', 'labfeed'), $res);
            throw new Exception($msg);
        }

        if (empty($html)) {
            throw new Exception(__('Página vazia.', 'labfeed'));
        }

        // Detecção básica de Cloudflare/Bot detection
        if (stripos($html, 'Checking your browser') !== false || 
            stripos($html, 'Cloudflare') !== false && stripos($html, 'Ray ID') !== false) {
            throw new Exception(__('Acesso bloqueado por proteção anti-bot (Cloudflare).', 'labfeed'));
        }

        // Usar DOMDocument para parsear HTML
        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML('<?xml encoding="UTF-8">' . $html);
        libxml_clear_errors();

        $xpath = new DOMXPath($dom);
        $items = array();

        // Seletores: primeiro tentar perfis por domínio, depois genéricos
        $queries = $this->get_link_queries_for_url($url);

        $seen_links = array();
        $irrelevant_keywords = array(
            'contato', 'sobre', 'anuncie', 'privacidade', 'termos', 'login', 'register',
            'autor', 'author', 'perfil', 'profile', 'configuracoes'
        );
        
        $excluded_section_keywords = array('falun gong', 'li hongzhi', 'pelo fundador do', 'fundador do falun', 'o criador busca');

        foreach ($queries as $query) {
            $nodes = $xpath->query($query);
            foreach ($nodes as $node) {
                $link = $node->getAttribute('href');
                $title = trim($node->nodeValue);
                
                // Limpar título e remover categoria duplicada no início (ex.: "BBB BBB Algo" -> "BBB Algo")
                $title = preg_replace('/\s+/', ' ', $title);
                $title = $this->strip_duplicate_category_prefix($title);
                
                if (empty($link) || strlen($title) < 15) continue;
                if ($this->is_date_or_category_only_title($title)) continue;

                // Converter link relativo para absoluto
                $absolute_link = $this->make_absolute_url($link, $url);
                if ($this->is_non_html_resource_link($absolute_link)) continue;
                if (!$this->is_allowed_article_link_for_host($absolute_link, $url)) continue;
                
                if (in_array($absolute_link, $seen_links)) continue;
                
                // Filtros básicos
                $link_lower = strtolower($absolute_link);
                $title_lower = strtolower($title);
                
                $skip = false;
                foreach ($irrelevant_keywords as $keyword) {
                    if (strpos($link_lower, $keyword) !== false || strpos($title_lower, $keyword) !== false) {
                        $skip = true;
                        break;
                    }
                }
                if ($skip) continue;
                
                // Filtro de palavras excluídas
                foreach ($excluded_section_keywords as $excl) {
                    if (strpos($title_lower, $excl) !== false) {
                        $skip = true;
                        break;
                    }
                }
                if ($skip) continue;

                // Evitar links de categorias/autores/etc
                if ($this->is_author_or_listing_link($absolute_link)) continue;

                // Tentar encontrar data e descrição no contexto
                $description = '';
                $pub_date = '';
                $author = '';
                
                $context_node = $node->parentNode;
                for ($i = 0; $i < 6; $i++) {
                    if (!$context_node) break;
                    
                    if (empty($description)) {
                        $p_nodes = $xpath->query(".//p", $context_node);
                        if ($p_nodes->length > 0) {
                            $description = trim($p_nodes->item(0)->nodeValue);
                        }
                    }
                    
                    if (empty($pub_date)) {
                        $pub_date = $this->extract_date($context_node, $xpath);
                    }
                    
                    if (empty($author)) {
                        $author = $this->extract_author($context_node, $xpath);
                    }
                    
                    $context_node = $context_node->parentNode;
                }

                $items[] = array(
                    'title' => $title,
                    'link' => $absolute_link,
                    'description' => $description,
                    'pub_date' => $pub_date,
                    'author' => $author
                );
                $seen_links[] = $absolute_link;
                
                if (count($items) >= 50) break 2;
            }
        }

        // Fallback: se nenhum link foi encontrado via XPath (ex.: página com pouco HTML ou JS), extrair do HTML bruto
        if (empty($items) && !empty($html)) {
            $items = $this->extract_links_from_raw_html($html, $url);
        }
        // Reaproveitar limite de itens para evitar processamento infinito
        $max_items = absint(get_option('labfeed_max_items', 15));
        if ($max_items > 0 && count($items) > $max_items) {
            $items = array_slice($items, 0, $max_items);
        }

        // Enriquecer cada item buscando o conteúdo completo da notícia (texto + imagem)
        // O enriquecimento é lento, então limitamos a no máximo 10 itens por vez para evitar timeout do servidor
        $items_to_enrich = array_slice($items, 0, 10);
        $enriched_items = $this->enrich_items_with_content($items_to_enrich);
        
        // Se pegamos mais que 10 na listagem, unimos os enriquecidos com o restante (sem conteúdo extra)
        if (count($items) > 10) {
            $remaining = array_slice($items, 10);
            $items = array_merge($enriched_items, $remaining);
        } else {
            $items = $enriched_items;
        }

        return $items;
    }

    /**
     * Para cada item encontrado na listagem, tenta abrir a página da notícia
     * e extrair conteúdo mais rico (texto e imagem principal).
     */
    private function enrich_items_with_content($items) {
        if (empty($items) || !is_array($items)) {
            return $items;
        }

        foreach ($items as &$item) {
            if (empty($item['link']) || !filter_var($item['link'], FILTER_VALIDATE_URL)) {
                continue;
            }

            // Sempre tentamos enriquecer para priorizar conteúdo completo da página da notícia.
            $existing_description = isset($item['description']) ? trim($item['description']) : '';

            try {
                $enriched = $this->fetch_article_content($item['link']);
            } catch (Exception $e) {
                $enriched = null;
            }

            if (!is_array($enriched)) {
                continue;
            }

            if (!empty($enriched['description'])) {
                // Prioriza sempre a descrição enriquecida (conteúdo completo do artigo).
                $item['description'] = $enriched['description'];
            } elseif (!empty($existing_description)) {
                // Fallback: mantém o texto da listagem somente quando não houver conteúdo no artigo.
                $item['description'] = $existing_description;
            }

            if (!empty($enriched['pub_date']) && empty($item['pub_date'])) {
                $item['pub_date'] = $enriched['pub_date'];
            }

            if (!empty($enriched['author']) && empty($item['author'])) {
                $item['author'] = $enriched['author'];
            }
        }

        return $items;
    }

    /**
     * Busca o HTML da notícia individual e tenta montar uma descrição rica:
     * primeiros parágrafos + imagem principal (quando existir).
     */
    private function fetch_article_content($url) {
        $response = wp_remote_get($url, array(
            'timeout'   => 20,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'headers' => array(
                'Referer' => $this->get_site_referer($url),
                'Accept-Language' => 'pt-BR,pt;q=0.9,en;q=0.8'
            ),
            'sslverify' => false
        ));

        if (is_wp_error($response)) {
            return null;
        }

        $code = wp_remote_retrieve_response_code($response);
        $html = wp_remote_retrieve_body($response);

        if ($code !== 200 || empty($html)) {
            return null;
        }

        // Detecção básica de páginas bloqueadas / JS-only
        if (stripos($html, 'Checking your browser') !== false ||
            (stripos($html, 'Cloudflare') !== false && stripos($html, 'Ray ID') !== false)) {
            return null;
        }

        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML('<?xml encoding="UTF-8">' . $html);
        libxml_clear_errors();

        $xpath = new DOMXPath($dom);

        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        $content_queries = array();
        if (strpos($host, 'campos.rj.gov.br') !== false) {
            $content_queries = array(
                "//div[contains(@class,'box-detail-noticia')]//div[contains(@class,'imateria')]",
                "//div[contains(@class,'box-detail-noticia')]//*[contains(@class,'materia')]",
                "//div[contains(@class,'imateria')]",
            );
        }
        if (strpos($host, 'pmvc.ba.gov.br') !== false || (strpos($host, 'rolandia') !== false && strpos($host, 'gov') !== false)) {
            $content_queries = array_merge($content_queries, array(
                "//div[contains(@class,'materia') or contains(@class,'noticia-conteudo') or contains(@class,'conteudo-noticia') or contains(@class,'noticia')]",
                "//main//div[contains(@class,'content') or contains(@class,'post')]",
                "//article",
                "//div[contains(@class,'entry-content') or contains(@class,'post-content')]",
            ));
        }
        if (strpos($host, 'rj.gov.br') !== false) {
            $content_queries = array_merge($content_queries, array(
                "//article//div[contains(@class,'content') or contains(@class,'conteudo') or contains(@class,'body')]",
                "//main//div[contains(@class,'content') or contains(@class,'post') or contains(@class,'noticia')]",
                "//div[contains(@class,'entry-content') or contains(@class,'post-content') or contains(@class,'materia')]",
                "//article",
            ));
        }
        if (strpos($host, 'revistaoeste.com') !== false || strpos($host, 'achouquetop.com') !== false) {
            $content_queries = array_merge($content_queries, array(
                "//article//div[contains(@class,'entry-content') or contains(@class,'post-content') or contains(@class,'content')]",
                "//div[contains(@class,'entry-content') or contains(@class,'post-content')]",
                "//main//article",
                "//article",
            ));
        }
        $content_queries = array_merge($content_queries, array(
            "//article[contains(@class,'post') or contains(@class,'single') or contains(@class,'noticia')]",
            "//div[contains(@class,'entry-content') or contains(@class,'post-content') or contains(@class,'single-content') or contains(@class,'noticia-conteudo')]",
            "//main//*[contains(@class,'content') or contains(@class,'post-body') or contains(@class,'article-body')]",
            "//div[contains(@class,'content') and not(contains(@class,'menu')) and not(contains(@class,'nav'))]",
        ));

        $content_node = null;
        foreach ($content_queries as $query) {
            $nodes = $xpath->query($query);
            if ($nodes->length > 0) {
                $content_node = $nodes->item(0);
                break;
            }
        }

        if (!$content_node) {
            $bodies = $xpath->query('//body');
            if ($bodies->length > 0) {
                $content_node = $bodies->item(0);
            } else {
                return null;
            }
        }

        // Limpar elementos irrelevantes (menus, popups, scripts etc.) antes de extrair o conteúdo
        $this->clean_content_node($content_node);

        $is_campos = (strpos($host, 'campos.rj.gov.br') !== false);
        $description_html = '';

        if ($is_campos) {
            // Campos/RJ: priorizar o corpo integral da matéria para evitar pegar resumo/listagem.
            $campos_body_nodes = $xpath->query("//div[contains(@class,'box-detail-noticia')]//div[contains(@class,'imateria')]");
            if ($campos_body_nodes && $campos_body_nodes->length > 0) {
                $description_html = $this->get_inner_html($campos_body_nodes->item(0));
            }
        }

        // Extração genérica: reunir todos os parágrafos disponíveis.
        if (empty(trim(strip_tags($description_html)))) {
            $paragraphs = $xpath->query('.//p', $content_node);
            $html_parts = array();

            if ($paragraphs->length > 0) {
                foreach ($paragraphs as $p) {
                    $text = trim($p->textContent);
                    if ($text === '') {
                        continue;
                    }
                    $html_parts[] = $this->get_node_html($p);
                }
            }

            $description_html = implode("\n", $html_parts);
        }

        // Se ainda não conseguimos parágrafos úteis, usamos o bloco completo do conteúdo
        if (empty(trim(strip_tags($description_html)))) {
            $description_html = $this->get_inner_html($content_node);
        }

        // Buscar imagem principal
        $img_html = '';
        $img_nodes = $xpath->query('.//img', $content_node);
        if ($img_nodes->length > 0) {
            $img_node = $img_nodes->item(0);
            $src = $img_node->getAttribute('src');
            if (empty($src)) $src = $img_node->getAttribute('data-src');
            if (empty($src)) $src = $img_node->getAttribute('data-original');
            if (!empty($src)) {
                $absolute_src = $this->make_absolute_url($src, $url);
                $img_html = '<p><img src="' . esc_url($absolute_src) . '" alt="" /></p>';
            }
        }
        // Fallback: quando o bloco principal não contém <img>, tentar Open Graph/Twitter image
        if (empty($img_html)) {
            $meta_img_queries = array(
                "//meta[@property='og:image']/@content",
                "//meta[@name='twitter:image']/@content",
                "//meta[@property='twitter:image']/@content"
            );
            foreach ($meta_img_queries as $q) {
                $meta_nodes = $xpath->query($q);
                if ($meta_nodes && $meta_nodes->length > 0) {
                    $meta_src = trim($meta_nodes->item(0)->nodeValue);
                    if (!empty($meta_src)) {
                        $absolute_src = $this->make_absolute_url($meta_src, $url);
                        $img_html = '<p><img src="' . esc_url($absolute_src) . '" alt="" /></p>';
                        break;
                    }
                }
            }
        }

        $final_description = $img_html . $description_html;

        // Rejeitar conteúdo que parece menu/listagem (muitos links, pouco texto)
        if (!$this->is_likely_article_content($final_description)) {
            $final_description = '';
        }

        // Extrair dados via JSON-LD (muito mais preciso)
        $json_ld = $this->extract_from_json_ld($html);

        // Reaproveitar lógica de data/autor, agora na página da notícia
        $pub_date = !empty($json_ld['pub_date']) ? $json_ld['pub_date'] : $this->extract_date($content_node, $xpath);
        $author   = !empty($json_ld['author']) ? $json_ld['author'] : $this->extract_author($content_node, $xpath);

        // Se o JSON-LD forneceu título mas não tínhamos nada, ou se a imagem do JSON-LD for melhor
        $img_from_json = !empty($json_ld['image']) ? '<p><img src="' . esc_url($json_ld['image']) . '" alt="" /></p>' : '';
        if ($img_from_json && empty($img_html)) {
            $img_html = $img_from_json;
        }

        $final_description = $img_html . $description_html;

        // Rejeitar conteúdo que parece menu/listagem (muitos links, pouco texto)
        if (!$this->is_likely_article_content($final_description)) {
            // Se falhou, tentamos uma última heurística: o nó com mais parágrafos significativos
            $heuristic_content = $this->find_main_content_heuristic($xpath);
            if ($heuristic_content) {
                $final_description = $img_html . $heuristic_content;
            } else {
                $final_description = '';
            }
        }

        return array(
            'description'    => $final_description,
            'pub_date'       => $pub_date,
            'author'         => $author,
            'json_ld_title'  => !empty($json_ld['title']) ? $json_ld['title'] : ''
        );
    }

    /**
     * Verifica se o HTML extraído parece conteúdo de artigo (e não menu/navegação).
     */
    private function is_likely_article_content($html) {
        $html = trim($html);
        if ($html === '') return false;
        $stripped = strip_tags($html);
        $stripped = preg_replace('/\s+/', ' ', $stripped);
        $stripped = trim($stripped);
        $len = mb_strlen($stripped, 'UTF-8');
        if ($len < 80) return false;
        $link_count = substr_count(strtolower($html), '<a ');
        if ($link_count > 15 && $len < 500) return false;
        $menu_words = array('início', 'sobre', 'contato', 'buscar', 'pesquisar', 'menu', 'nav', 'categorias');
        foreach ($menu_words as $w) {
            if (mb_strpos(mb_strtolower($stripped), $w) === 0 && $len < 200) return false;
        }
        return true;
    }

    /**
     * Retorna o HTML completo de um nó específico.
     */
    private function get_node_html(DOMNode $node) {
        if (!$node->ownerDocument) {
            return '';
        }
        return $node->ownerDocument->saveHTML($node);
    }

    /**
     * Retorna o HTML interno (innerHTML) de um nó.
     */
    private function get_inner_html(DOMNode $node) {
        if (!$node->ownerDocument || !$node->hasChildNodes()) {
            return '';
        }
        $html = '';
        foreach ($node->childNodes as $child) {
            $html .= $node->ownerDocument->saveHTML($child);
        }
        return $html;
    }

    /**
     * Remove nós irrelevantes (scripts, estilos, popups, cabeçalho/rodapé, menus)
     * da região de conteúdo antes de extrair o texto principal.
     */
    private function clean_content_node(DOMNode $node) {
        if (!$node->ownerDocument) {
            return;
        }

        $document = $node->ownerDocument;
        $xpath    = new DOMXPath($document);

        // Remover tags de script/estilo e similares
        $tags_to_strip = array('script', 'style', 'noscript', 'iframe', 'object', 'svg', 'link', 'meta');
        foreach ($tags_to_strip as $tag) {
            // getElementsByTagName é live; remover sempre o primeiro até esvaziar
            while (true) {
                $list = $node->getElementsByTagName($tag);
                if ($list->length === 0) {
                    break;
                }
                $current = $list->item(0);
                if ($current && $current->parentNode) {
                    $current->parentNode->removeChild($current);
                } else {
                    break;
                }
            }
        }

        // Remover blocos típicos de menu, cabeçalho, rodapé, barras e popups
        $patterns = array(
            'menu', 'nav', 'header', 'footer', 'popup', 'modal', 'newsletter', 'cookie', 'toolbar', 'sidebar',
            'breadcrumb', 'share', 'social', 'related', 'recommended', 'tags', 'categories', 'author-box', 'comments',
            'widget', 'banner', 'ads', 'advertising', 'outbrain', 'taboola'
        );
        $conditions = array();
        foreach ($patterns as $p) {
            $p_lower = strtolower($p);
            $conditions[] = "contains(translate(@id, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '$p_lower')";
            $conditions[] = "contains(translate(@class, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '$p_lower')";
        }

        if (!empty($conditions)) {
            $query = './/*[' . implode(' or ', $conditions) . ']';
            $nodes = $xpath->query($query, $node);
            if ($nodes && $nodes->length > 0) {
                // Copiar os nós para array para evitar problemas com NodeList dinâmico
                $to_remove = array();
                foreach ($nodes as $n) {
                    $to_remove[] = $n;
                }
                foreach ($to_remove as $n) {
                    if ($n->parentNode) {
                        $n->parentNode->removeChild($n);
                    }
                }
            }
        }
    }

    private function make_absolute_url($rel, $base) {
        if (parse_url($rel, PHP_URL_SCHEME) != '') return $rel;
        if ($rel[0] == '#' || $rel[0] == '?') return $base . $rel;
        
        extract(parse_url($base));
        $path = preg_replace('#/[^/]*$#', '', $path);
        if ($rel[0] == '/') $path = '';
        
        $abs = "$host$path/$rel";
        $re = array('#(/\.?/)#', '#/(?!\.\.)[^/]+/\.\./#');
        for ($n = 1; $n > 0; $abs = preg_replace($re, '/', $abs, -1, $n)) {}
        
        return $scheme . '://' . $abs;
    }

    /**
     * Descarta links de arquivos binários/estáticos que não devem virar item de feed.
     */
    private function is_non_html_resource_link($url) {
        $path = (string) parse_url($url, PHP_URL_PATH);
        $ext = strtolower((string) pathinfo($path, PATHINFO_EXTENSION));
        if ($ext === '') {
            return false;
        }
        $blocked = array(
            'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'zip', 'rar', '7z',
            'jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'mp4', 'mp3', 'avi'
        );
        return in_array($ext, $blocked, true);
    }

    /**
     * Regra específica por domínio para aceitar apenas URLs que parecem artigos/notícias.
     */
    private function is_allowed_article_link_for_host($url, $source_url) {
        $host = strtolower((string) parse_url($source_url, PHP_URL_HOST));
        $link = strtolower((string) $url);

        // Campos/RJ: notícias reais ficam em exibirNoticia.php?id_noticia=...
        if (strpos($host, 'campos.rj.gov.br') !== false) {
            return (strpos($link, 'exibirnoticia.php') !== false && strpos($link, 'id_noticia=') !== false);
        }

        return true;
    }

    /**
     * Detecta se a URL é de listagem, categoria, autor, tag ou paginação (não é artigo).
     * Rigoroso para evitar que links de seção entrem no feed.
     */
    private function is_author_or_listing_link($url) {
        $path = (string) parse_url($url, PHP_URL_PATH);
        $path_lower = mb_strtolower($path, 'UTF-8');
        $query = (string) parse_url($url, PHP_URL_QUERY);

        $path_patterns = array(
            '/\/category\//',
            '/\/categoria\//',
            '/\/categorias\//',
            '/\/tag\//',
            '/\/author\//',
            '/\/page\/\d/',           // paginação /page/2
            '/\/secretaria\//',       // PMVC e similares
            '/\/arquivo\//',
            '/\/busca\//',
            '/\/search\//',
            '/\/feed\//',
            '/\/canal\/[^\/]+\/page\//'  // maisnovela paginação
        );
        foreach ($path_patterns as $pattern) {
            if (preg_match($pattern, $path_lower)) return true;
        }
        if (preg_match('/\?(cat|tag|author|page|paged)=/i', $query)) return true;
        return false;
    }

    /**
     * Remove categoria duplicada no início do título (ex.: "BBB BBB Algo" -> "BBB Algo").
     * Evita que o nome da categoria apareça duas vezes quando já está no título.
     */
    private function strip_duplicate_category_prefix($title) {
        $t = trim($title);
        if ($t === '') return $title;
        if (preg_match('/^(\S+)\s+\1\s+/iu', $t, $m)) {
            return trim(preg_replace('/^(\S+)\s+\1\s+/iu', $m[1] . ' ', $t, 1));
        }
        return $title;
    }

    /**
     * Verifica se o texto do link parece ser só data/categoria (não título de notícia).
     */
    private function is_date_or_category_only_title($title) {
        $t = trim($title);
        if ($t === '') return true;
        // Apenas data no formato DD/MM/YYYY ou "BBB DD/MM/YYYY"
        if (preg_match('/^(\w+\s+)?\d{1,2}\/\d{1,2}\/\d{2,4}$/u', $t)) return true;
        // Apenas uma palavra (ex: categoria "BBB", "Notícias")
        if (preg_match('/^\w+$/u', $t) && mb_strlen($t) < 25) return true;
        return false;
    }

    private function extract_date($element, $xpath) {
        $now_ts = function_exists('current_time') ? current_time('timestamp') : time();
        $queries = array(
            ".//time/@datetime",
            ".//meta[@property='article:published_time']/@content",
            ".//*[contains(@class, 'date')]",
            ".//*[contains(@class, 'time')]"
        );
        foreach ($queries as $query) {
            $nodes = $xpath->query($query, $element);
            if ($nodes->length > 0) {
                $date_str = trim($nodes->item(0)->nodeValue);
                $ts = strtotime($date_str);
                if ($ts !== false && $ts <= $now_ts) {
                    return date('Y-m-d H:i:s', $ts);
                }
            }
        }

        // Fallback: texto do nó e de pais (card de listagem pode ter "Data: 24 Fev" ou "12/03/2026 - 15:13:19")
        $raw_text = '';
        if (is_object($element) && property_exists($element, 'textContent')) {
            $raw_text = trim($element->textContent);
        }
        if ($raw_text !== '') {
            $parsed = $this->parse_brazilian_date_string($raw_text);
            if (!empty($parsed)) return $parsed;
        }
        $parent = $element->parentNode;
        for ($j = 0; $j < 2 && $parent; $j++) {
            $raw_text = trim($parent->textContent);
            if ($raw_text !== '') {
                $parsed = $this->parse_brazilian_date_string($raw_text);
                if (!empty($parsed)) return $parsed;
            }
            $parent = $parent->parentNode;
        }
        return '';
    }

    /**
     * Tenta converter datas escritas em português para o formato Y-m-d H:i:s.
     * Exemplos aceitos:
     * - "24 Fev, 2026"
     * - "24 de fevereiro de 2026"
     * - "24/02/2026"
     * - "24-02-2026"
     * - "3 minutos atrás", "14 minutos atrás", "5 horas atrás", "2 dias atrás"
     */
    private function parse_brazilian_date_string($text) {
        if ($text === '') {
            return '';
        }
        $now_ts = function_exists('current_time') ? current_time('timestamp') : time();

        $months = array(
            'janeiro'   => 1,
            'fevereiro' => 2,
            'março'     => 3,
            'marco'     => 3,
            'abril'     => 4,
            'maio'      => 5,
            'junho'     => 6,
            'julho'     => 7,
            'agosto'    => 8,
            'setembro'  => 9,
            'outubro'   => 10,
            'novembro'  => 11,
            'dezembro'  => 12,
            'jan'       => 1,
            'fev'       => 2,
            'mar'       => 3,
            'abr'       => 4,
            'mai'       => 5,
            'jun'       => 6,
            'jul'       => 7,
            'ago'       => 8,
            'set'       => 9,
            'out'       => 10,
            'nov'       => 11,
            'dez'       => 12,
        );

        $text_lower = mb_strtolower($text, 'UTF-8');

        // "Data: 24 Fev" ou "24 Fev" (dia + mês abreviado, ano opcional)
        $pattern_data_fev = '/(?:data|autor)?\s*:?\s*(\d{1,2})\s*(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)(?:[,\s]+(\d{4}))?/iu';
        if (preg_match($pattern_data_fev, $text_lower, $md)) {
            $day   = intval($md[1]);
            $month = isset($months[$md[2]]) ? (int) $months[$md[2]] : 0;
            $year  = !empty($md[3]) ? intval($md[3]) : intval(date('Y'));
            if ($day >= 1 && $day <= 31 && $month >= 1 && $month <= 12) {
                $ts = mktime(0, 0, 0, $month, $day, $year);
                if ($ts <= $now_ts) {
                    return date('Y-m-d H:i:s', $ts);
                }
                return '';
            }
        }

        // Formatos relativos: "3 minutos atrás", "14 minutos atrás", "5 horas atrás", "2 dias atrás"
        $pattern_relative = '/(\d+)\s*(minuto|minutos|hora|horas|dia|dias)\s+atrás/iu';
        if (preg_match($pattern_relative, $text_lower, $mr)) {
            $amount = intval($mr[1]);
            $unit   = $mr[2];

            if ($amount > 0) {
                $now_ts = function_exists('current_time') ? current_time('timestamp') : time();
                switch ($unit) {
                    case 'minuto':
                    case 'minutos':
                        $delta = $amount * 60;
                        break;
                    case 'hora':
                    case 'horas':
                        $delta = $amount * 3600;
                        break;
                    case 'dia':
                    case 'dias':
                        $delta = $amount * 86400;
                        break;
                    default:
                        $delta = 0;
                }

                if ($delta > 0) {
                    return date('Y-m-d H:i:s', $now_ts - $delta);
                }
            }
        }

        // Formatos com nome de mês: "24 de fevereiro de 2026", "24 fev 2026", "24 Fev, 2026"
        $pattern_month = '/(\d{1,2})\s*(de)?\s*(janeiro|fevereiro|mar[cç]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro|jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[^\d]{0,10}(\d{4})?/iu';
        if (preg_match($pattern_month, $text_lower, $m)) {
            $day = intval($m[1]);
            $month_name = str_replace('ç', 'c', $m[3]);
            $month_name = str_replace('ã', 'a', $month_name);
            $month_name = str_replace('á', 'a', $month_name);
            $month_name = str_replace('é', 'e', $month_name);
            $month_name = str_replace('í', 'i', $month_name);
            $month_name = str_replace('ó', 'o', $month_name);
            $month_name = str_replace('ú', 'u', $month_name);
            $month_name = strtolower($month_name);

            if (!isset($months[$month_name])) {
                return '';
            }

            $month = (int) $months[$month_name];
            $year  = !empty($m[4]) ? intval($m[4]) : intval(date('Y'));

            if ($day >= 1 && $day <= 31 && $month >= 1 && $month <= 12) {
                $ts = mktime(0, 0, 0, $month, $day, $year);
                if ($ts <= $now_ts) {
                    return date('Y-m-d H:i:s', $ts);
                }
                return '';
            }
        }

        // Formato numérico com hora:
        // "24/02/2026 14:21:52", "24-02-2026 14:21", "24/02/2026 - 14:21:52", "24/02/2026 às 14:21"
        $pattern_numeric_time = '/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})\s*(?:-|–|—|às|as|,)?\s*(\d{1,2}):(\d{2})(?::(\d{2}))?/u';
        if (preg_match($pattern_numeric_time, $text_lower, $m2)) {
            $day   = intval($m2[1]);
            $month = intval($m2[2]);
            $year  = intval($m2[3]);
            $hour  = intval($m2[4]);
            $min   = intval($m2[5]);
            $sec   = isset($m2[6]) ? intval($m2[6]) : 0;

            if ($year < 100) {
                // assumir século 2000+
                $year += 2000;
            }

            if ($day >= 1 && $day <= 31 && $month >= 1 && $month <= 12) {
                $ts = mktime($hour, $min, $sec, $month, $day, $year);
                if ($ts <= $now_ts) {
                    return date('Y-m-d H:i:s', $ts);
                }
                return '';
            }
        }

        // Formato numérico sem hora: "24/02/2026" ou "24-02-2026"
        $pattern_numeric = '/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/';
        if (preg_match($pattern_numeric, $text_lower, $m2)) {
            $day   = intval($m2[1]);
            $month = intval($m2[2]);
            $year  = intval($m2[3]);

            if ($year < 100) {
                // assumir século 2000+
                $year += 2000;
            }

            if ($day >= 1 && $day <= 31 && $month >= 1 && $month <= 12) {
                $ts = mktime(0, 0, 0, $month, $day, $year);
                if ($ts <= $now_ts) {
                    return date('Y-m-d H:i:s', $ts);
                }
                return '';
            }
        }

        return '';
    }

    private function extract_author($element, $xpath) {
        $queries = array(
            ".//*[contains(@class, 'author')]",
            ".//*[contains(@class, 'byline')]",
            ".//a[contains(@rel, 'author')]",
            "//meta[@name='author']/@content",
            "//meta[@property='article:author']/@content"
        );
        
        foreach ($queries as $query) {
            $nodes = $xpath->query($query, $element);
            if ($nodes->length > 0) {
                $author = trim($nodes->item(0)->nodeValue);
                $author = preg_replace('/^(por|by|autor|author):?\s*/i', '', $author);
                if (!empty($author) && strlen($author) < 50) return $author;
            }
        }
        return '';
    }

    /**
     * Extrai dados estruturados (JSON-LD) para obter metadados precisos.
     */
    private function extract_from_json_ld($html) {
        if (empty($html)) return array();
        
        $res = array();
        if (preg_match_all('/<script type="application\/ld\+json">(.*?)<\/script>/is', $html, $matches)) {
            foreach ($matches[1] as $json_str) {
                $data = json_decode($json_str, true);
                if (empty($data)) continue;

                // Pode ser um array de objetos ou um único objeto
                $items = isset($data['@graph']) ? $data['@graph'] : (isset($data[0]) ? $data : array($data));

                foreach ($items as $item) {
                    $type = isset($item['@type']) ? $item['@type'] : '';
                    if (is_array($type)) $type = implode(' ', $type);
                    
                    if (stripos($type, 'NewsArticle') !== false || stripos($type, 'BlogPosting') !== false || stripos($type, 'Article') !== false) {
                        if (empty($res['title']) && !empty($item['headline'])) $res['title'] = $item['headline'];
                        if (empty($res['pub_date']) && !empty($item['datePublished'])) $res['pub_date'] = date('Y-m-d H:i:s', strtotime($item['datePublished']));
                        if (empty($res['image']) && !empty($item['image'])) {
                            if (is_array($item['image'])) {
                                $res['image'] = isset($item['image']['url']) ? $item['image']['url'] : (isset($item['image'][0]) ? $item['image'][0] : '');
                            } else {
                                $res['image'] = $item['image'];
                            }
                        }
                        if (empty($res['author']) && !empty($item['author'])) {
                            if (is_array($item['author'])) {
                                $res['author'] = isset($item['author']['name']) ? $item['author']['name'] : (isset($item['author'][0]['name']) ? $item['author'][0]['name'] : '');
                            } else {
                                $res['author'] = $item['author'];
                            }
                        }
                    }
                }
            }
        }
        return $res;
    }

    /**
     * Heurística para encontrar o conteúdo principal baseada em densidade de texto
     * quando os seletores XPath falham.
     */
    private function find_main_content_heuristic($xpath) {
        $nodes = $xpath->query('//div|//section|//main|//article');
        $best_node = null;
        $max_p_count = 0;

        foreach ($nodes as $node) {
            $p_nodes = $xpath->query('.//p', $node);
            $p_count = 0;
            foreach ($p_nodes as $p) {
                if (mb_strlen(trim($p->textContent), 'UTF-8') > 20) {
                    $p_count++;
                }
            }

            if ($p_count > $max_p_count) {
                $max_p_count = $p_count;
                $best_node = $node;
            }
        }

        if ($best_node && $max_p_count >= 2) {
            // Limpar novamente o nó escolhido caso ele contenha lixo
            $this->clean_content_node($best_node);
            
            $paragraphs = $xpath->query('.//p', $best_node);
            $html_parts = array();
            foreach ($paragraphs as $p) {
                if (mb_strlen(trim($p->textContent), 'UTF-8') > 15) {
                    $html_parts[] = $this->get_node_html($p);
                }
            }
            return implode("\n", $html_parts);
        }

        return '';
    }

    public function admin_assets($hook) {
        if (strpos($hook, 'labfeed') === false) return;
        wp_enqueue_style('labfeed-admin', plugin_dir_url(__FILE__) . 'assets/css/admin.css', array(), '4.4.0');
        wp_enqueue_script('labfeed-admin', plugin_dir_url(__FILE__) . 'assets/js/admin.js', array('jquery'), '4.4.0', true);
        wp_localize_script('labfeed-admin', 'labfeedAdmin', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('labfeed_add_feed'),
            'i18n' => array(
                'success' => __('Feed cadastrado com sucesso! Será atualizado automaticamente a cada 5 minutos.', 'labfeed'),
                'error' => __('Erro ao cadastrar. Verifique os dados e tente novamente.', 'labfeed'),
                'loading' => __('Salvando...', 'labfeed'),
                'submit' => __('Cadastrar feed', 'labfeed'),
                'empty' => __('Nenhum item', 'labfeed'),
                'invalidUrl' => __('Informe uma URL válida (ex: https://exemplo.com/secao/)', 'labfeed')
            )
        ));
    }

    public function ajax_add_feed() {
        check_ajax_referer('labfeed_add_feed', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Sem permissão.', 'labfeed')));
        }
        
        // Bloquear se a licença não estiver ativa
        if (!LabFeed_License::is_active()) {
            wp_send_json_error(array('message' => __('Licença inativa. Ative o plugin para adicionar feeds.', 'labfeed')));
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'labfeed_links';
        $site_name = isset($_POST['site_name']) ? sanitize_text_field($_POST['site_name']) : '';
        $target_url = isset($_POST['target_url']) ? esc_url_raw($_POST['target_url']) : '';
        if (empty($site_name) || empty($target_url) || !filter_var($target_url, FILTER_VALIDATE_URL)) {
            wp_send_json_error(array('message' => __('Preencha nome e URL válida do site.', 'labfeed')));
        }
        $data = array(
            'site_name' => $site_name,
            'target_url' => $target_url,
            'feed_title' => '',
            'feed_description' => ''
        );
        $result = $wpdb->insert($table_name, $data);
        if ($result === false) {
            wp_send_json_error(array('message' => $wpdb->last_error ?: __('Erro ao salvar.', 'labfeed')));
        }
        $id = $wpdb->insert_id;
        $feed_url = home_url('/feed/labxml/?id=' . $id);
        wp_send_json_success(array(
            'id' => $id,
            'site_name' => $site_name,
            'feed_title' => '',
            'target_url' => $target_url,
            'feed_url' => $feed_url,
            'last_update' => __('Nunca', 'labfeed'),
            'items_count' => 0,
            'edit_url' => admin_url('admin.php?page=labfeed-edit&id=' . $id),
            'delete_url' => wp_nonce_url(add_query_arg('delete', $id, admin_url('admin.php?page=labfeed')), 'delete_link_' . $id)
        ));
    }

    public function admin_menu() {
        add_menu_page(__('LabFeed', 'labfeed'), __('LabFeed', 'labfeed'), 'manage_options', 'labfeed', array($this, 'admin_dashboard'), 'dashicons-rss', 30);
        add_submenu_page('labfeed', __('Todos os Feeds', 'labfeed'), __('Todos os Feeds', 'labfeed'), 'manage_options', 'labfeed', array($this, 'admin_dashboard'));
        add_submenu_page('labfeed', __('Novo Feed', 'labfeed'), __('Novo Feed', 'labfeed'), 'manage_options', 'labfeed-add', array($this, 'admin_add_feed'));
        add_submenu_page('labfeed', __('Logs', 'labfeed'), __('Logs', 'labfeed'), 'manage_options', 'labfeed-logs', array($this, 'admin_logs'));
        add_submenu_page('labfeed', __('Configurações', 'labfeed'), __('Configurações', 'labfeed'), 'manage_options', 'labfeed-settings', array($this, 'admin_settings'));
        add_submenu_page(null, __('Editar Feed', 'labfeed'), __('Editar Feed', 'labfeed'), 'manage_options', 'labfeed-edit', array($this, 'admin_edit_feed'));
    }

    public function admin_dashboard() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'labfeed_links';

        if (isset($_GET['labfeed_430_dismiss']) && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'labfeed_430_dismiss')) {
            delete_transient('labfeed_430_replace_notice');
            wp_safe_redirect(admin_url('admin.php?page=labfeed'));
            exit;
        }
        if (isset($_GET['delete']) && isset($_GET['_wpnonce'])) {
            if (current_user_can('manage_options') && wp_verify_nonce($_GET['_wpnonce'], 'delete_link_' . $_GET['delete'])) {
                $wpdb->delete($table_name, array('id' => intval($_GET['delete'])));
                echo '<div class="notice notice-success is-dismissible"><p>' . __('Feed excluído com sucesso.', 'labfeed') . '</p></div>';
            }
        }
        if (isset($_GET['labfeed_added']) && $_GET['labfeed_added'] === '1') {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Feed cadastrado com sucesso! Será atualizado automaticamente a cada 5 minutos.', 'labfeed') . '</p></div>';
        }

        $links = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");
        if (!is_array($links)) {
            $links = array();
        }
        include __DIR__ . '/admin/views/dashboard.php';
    }

    public function admin_add_feed() {
        // Bloquear se a licença não estiver ativa
        if (!LabFeed_License::is_active()) {
            echo '<div class="wrap"><h1>LabFeed</h1><div class="notice notice-error"><p>Ative sua licença nas configurações para adicionar novos feeds.</p></div></div>';
            return;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'labfeed_links';
        $labfeed_form_error = '';

        if (isset($_POST['save_link']) && isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'save_link')) {
            $site_name = isset($_POST['site_name']) ? sanitize_text_field(wp_unslash($_POST['site_name'])) : '';
            $target_url = isset($_POST['target_url']) ? esc_url_raw(wp_unslash($_POST['target_url'])) : '';
            if (!empty($site_name) && !empty($target_url) && filter_var($target_url, FILTER_VALIDATE_URL)) {
                $data = array(
                    'site_name' => $site_name,
                    'target_url' => $target_url,
                    'feed_title' => '',
                    'feed_description' => ''
                );
                $result = $wpdb->insert($table_name, $data);
                if ($result !== false) {
                    wp_safe_redirect(admin_url('admin.php?page=labfeed&labfeed_added=1'));
                    exit;
                }
                $labfeed_form_error = __('Erro ao salvar.', 'labfeed');
            } else {
                $labfeed_form_error = __('Preencha os campos obrigatórios.', 'labfeed');
            }
        }
        include __DIR__ . '/admin/views/add-feed.php';
    }

    public function admin_logs() {
        if (isset($_GET['labfeed_clear_logs']) && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'labfeed_clear_logs')) {
            update_option('labfeed_logs', array());
            wp_safe_redirect(admin_url('admin.php?page=labfeed-logs'));
            exit;
        }
        $logs = get_option('labfeed_logs', array());
        if (!is_array($logs)) {
            $logs = array();
        }
        include __DIR__ . '/admin/views/logs.php';
    }

    public function admin_edit_feed() {
        if (!current_user_can('manage_options')) {
            wp_die(__('Você não tem permissão para acessar esta página.', 'labfeed'));
        }
        global $wpdb;
        $table_name = $wpdb->prefix . 'labfeed_links';
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        $feed = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
        if (!$feed) {
            wp_redirect(admin_url('admin.php?page=labfeed'));
            exit;
        }
        if (isset($_POST['update_feed']) && isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'update_feed_' . $id)) {
            $site_name = sanitize_text_field($_POST['site_name']);
            $target_url = esc_url_raw($_POST['target_url']);
            $wpdb->update($table_name, array(
                'site_name' => $site_name,
                'target_url' => $target_url,
                'feed_title' => '',
                'feed_description' => ''
            ), array('id' => $id));
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Feed atualizado.', 'labfeed') . '</p></div>';
            $feed = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
        }
        include __DIR__ . '/admin/views/edit-feed.php';
    }

    public function admin_settings() {
        if (!current_user_can('manage_options')) {
            wp_die(__('Você não tem permissão para acessar esta página.', 'labfeed'));
        }
        if (isset($_POST['labfeed_settings']) && isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['labfeed_settings_nonce'], 'labfeed_save_settings')) {
            $old_token = get_option('labfeed_license_token', '');
            $new_token = sanitize_text_field($_POST['license_token']);
            
            if ($old_token !== $new_token) {
                delete_transient('labfeed_license_' . md5($old_token));
                update_option('labfeed_license_token', $new_token);
                LabFeed_License::validate_remotely($new_token);
            }

            update_option('labfeed_cache_minutes', absint($_POST['cache_minutes']));
            update_option('labfeed_max_items', absint($_POST['max_items']));
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Configurações salvas.', 'labfeed') . '</p></div>';
        }
        $cache_minutes = get_option('labfeed_cache_minutes', 5);
        $max_items = get_option('labfeed_max_items', 20);
        $license_token = get_option('labfeed_license_token', '');
        include __DIR__ . '/admin/views/settings.php';
    }
}

new LabFeedConverter();
